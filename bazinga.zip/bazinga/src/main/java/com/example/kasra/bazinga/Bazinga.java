package com.example.kasra.bazinga;

import android.app.Application;
import android.content.Context;
import android.widget.Toast;
import com.example.kasra.bazinga.Utils.Logger;
import com.example.kasra.bazinga.Utils.NetUtils;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by Kasra on 3/14/2016.
 * Main Library class for Bazinga
 */
public class Bazinga
{
	private static final int DEFAULT_PORT = 55555;
	private static final Object locker = new Object();
	private static final int MAX_ALLOWABLE_RETRY = 10;

	private static BazingaServer bazingaServer;
	private static boolean initialized;
	private static Application applicationContext;

	public static Map<String, BazingaCustomFunction> getCustomFunctionMap()
	{
		return sCustomFunctionMap;
	}

	private static Map<String, BazingaCustomFunction> sCustomFunctionMap = new LinkedHashMap<>();


	public static void hook(String name, BazingaCustomFunction function, String... varNames)
	{
		if (sCustomFunctionMap.keySet().contains(name))
		{
			Logger.w("Function already exists with this name (" + name + ")... Ignoring this call!");
			return;
		}
		function.vars = varNames;
		sCustomFunctionMap.put(name, function);
	}

	public static void startAsync(Context context)
	{

		synchronized (locker)
		{

			if (initialized)
			{
				Logger.log("Bazinga already initialized... Ignoring this...");
				return;
			}

			applicationContext = (Application) context.getApplicationContext();

			initialized = true;

			Bazinga.hook("Show Toast", new BazingaCustomFunction()
			{
				@Override
				public String onCall(String[] objects)
				{
					String msg = objects[0];
					Toast.makeText(Bazinga.applicationContext, msg, Toast.LENGTH_SHORT).show();
					return "Success";
				}
			}, "ToastText");

			new Thread(new Runnable()
			{
				@Override
				public void run()
				{
					startNonAsync();
				}
			}).start();

		}
	}

	static public Application getApplicationContext()
	{
		return applicationContext;
	}

	private static void startNonAsync()
	{
		int port = DEFAULT_PORT;
		int counter = 0;

		while (bazingaServer == null)
		{

			if (counter > MAX_ALLOWABLE_RETRY)
			{
				throw new RuntimeException("Cannot allocate a port after " + MAX_ALLOWABLE_RETRY + " tries...  Something is wrong...");
			}

			bazingaServer = new BazingaServer(port);

			try
			{
				bazingaServer.start(1000);
			}
			catch (IOException e)
			{
				e.printStackTrace();
				try
				{
					bazingaServer.stop();
				}
				catch (Exception ignore)
				{
				}
				bazingaServer = null;
				port = new Random().nextInt(DEFAULT_PORT) + 10;
			}

			counter++;
		}

		Logger.log(" -------------------------------------------------------------------------------------------------------");
		Logger.log(" -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-. BAZINGA SERVER STARTED -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-. ");
		Logger.log(" If your development machine and android device are on the same wifi: http://" + NetUtils.getIPAddress(true) + ":" + port);
		Logger.log(" Otherwise, run \"adb forward tcp:" + port + " tcp:" + port + "\" in your terminal and then try http://127.0.0.1:" + port);
		Logger.log(" -------------------------------------------------------------------------------------------------------");
	}
}
