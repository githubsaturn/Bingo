package com.example.kasra.bazinga;

public abstract class BazingaCustomFunction
{
	public String[] vars = null;
	abstract public String onCall(String[] args);
}