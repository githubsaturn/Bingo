package com.example.kasra.bazinga;

import com.example.kasra.bazinga.Utils.Logger;
import com.example.kasra.bazinga.router.BaseRouter;
import com.example.kasra.bazinga.router.DummyRouter;
import com.example.kasra.bazinga.router.MainPage;
import com.example.kasra.bazinga.router.ReflectDebug;
import com.example.kasra.bazinga.router.RunCustomFunc;
import com.example.kasra.bazinga.router.StaticHtml;
import fi.iki.elonen.NanoHTTPD;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Kasra on 3/14/2016.
 * Simple Server taking care of everything!
 */
public class BazingaServer extends NanoHTTPD
{

	/**
	 * Common MIME type for dynamic content: css
	 */
	public static final String MIME_CSS = "text/css";
	private static final BaseRouter staticRouter = new StaticHtml();

	final private static HashMap<String, BaseRouter> routers = new LinkedHashMap<>();

	static
	{
		routers.put(ReflectDebug.URI_BASE, new ReflectDebug());
		routers.put(DummyRouter.URI_BASE, new DummyRouter());
		routers.put(MainPage.URI_BASE, new MainPage());
		routers.put(RunCustomFunc.URI_BASE, new RunCustomFunc());
	}

	BazingaServer(int port)
	{
		super(port);
	}

	@Override
	public Response serve(IHTTPSession session)
	{

		Logger.log("REQUEST URI: " + session.getUri());

		BaseRouter router = staticRouter;

		for (String uri : routers.keySet())
		{
			if (session.getUri().startsWith(uri))
			{
				router = routers.get(uri);
				break;
			}
		}

		try
		{
			return router.createResponse(session);
		}
		catch (Exception e)
		{
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			e.printStackTrace();
			return newFixedLengthResponse(Response.Status.BAD_REQUEST, NanoHTTPD.MIME_PLAINTEXT, errors.toString());
		}
	}

	public static Map<String, List<String>> decodeQueryParams(String queryString)
	{
		return decodeParameters(queryString);
	}

}
