package com.example.kasra.bazinga.router;

import com.example.kasra.bazinga.Bazinga;
import com.example.kasra.bazinga.BazingaServer;
import com.example.kasra.bazinga.Utils.Logger;
import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Kasra on 3/31/2016.
 * A base class for all routing classes
 */

public class StaticHtml extends BaseRouter
{
    public static final String URI_BASE = "/";

	public static final String STATIC_FOLDER = "static/";

	@Override
	public NanoHTTPD.Response createResponse(NanoHTTPD.IHTTPSession session)
	{
		{
			String pathFile = session.getUri().substring(URI_BASE.length());

			if (pathFile.isEmpty() || pathFile.equals("/"))
			{
				pathFile = "index.html";
			}

			pathFile = STATIC_FOLDER + pathFile;

			Logger.log("STATIC FILE: " + pathFile);

			String mimeType = BazingaServer.MIME_PLAINTEXT;
            if (pathFile.endsWith(".html"))
            {
                mimeType = BazingaServer.MIME_HTML;
            }
            else if (pathFile.endsWith(".css"))
            {
                mimeType = BazingaServer.MIME_CSS;
            }

			try
			{
				InputStream reader = Bazinga.getApplicationContext().getAssets().open(pathFile);
				return BazingaServer.newChunkedResponse(NanoHTTPD.Response.Status.OK, mimeType, reader);
			}
			catch (IOException e)
			{
				throw new RuntimeException(e);
			}
		}
	}
}
