package com.example.kasra.bazinga.router;

import android.os.Handler;
import android.os.Looper;
import com.example.kasra.bazinga.Bazinga;
import com.example.kasra.bazinga.BazingaCustomFunction;
import com.example.kasra.bazinga.BazingaServer;
import com.example.kasra.bazinga.Utils.common.util.IOUtils;
import fi.iki.elonen.NanoHTTPD;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;

/**
 * Created by Kasra on 3/31/2016.
 * A base class for all routing classes
 */

public class RunCustomFunc extends BaseRouter
{
	public static final String URI_BASE = "/customfunc";

	@Override
	public NanoHTTPD.Response createResponse(final NanoHTTPD.IHTTPSession session)
	{

		if (session.getMethod().equals(BazingaServer.Method.POST))
		{
			String rawInput = IOUtils.convertStreamToString(session.getInputStream());
			Map<String, List<String>> params = BazingaServer.decodeQueryParams(rawInput);

			String customMethodName = params.get("methodname").get(0);
			final BazingaCustomFunction method = Bazinga.getCustomFunctionMap().get(customMethodName);
			int numberOfParams = method.vars.length;
			final String[] args = new String[numberOfParams];
			for (int i = 0; i < args.length; i++)
			{
				args[i] = params.get(method.vars[i]).get(0);
			}

			final StringBuilder sb = new StringBuilder();
			final Semaphore lock = new Semaphore(1);

			try
			{
				lock.acquire();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}

			new Handler(Looper.getMainLooper()).post(new Runnable()
			{
				@Override
				public void run()
				{
					try
					{
						String msg = method.onCall(args);
						if (msg != null)
						{
							sb.append(msg);
						}
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
					finally
					{
						lock.release();
					}
				}
			});

			try
			{
				lock.acquire();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}

			return BazingaServer.newFixedLengthResponse(sb.toString());
		}
		else
		{
			throw new RuntimeException("This endpoint only accept post requests");
		}

	}

	private String toString(Map<String, ? extends Object> map)
	{
		if (map.size() == 0)
		{
			return "";
		}
		return unsortedList(map);
	}

	private String unsortedList(Map<String, ? extends Object> map)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<ul>");
		for (Map.Entry entry : map.entrySet())
		{
			listItem(sb, entry);
		}
		sb.append("</ul>");
		return sb.toString();
	}

	private void listItem(StringBuilder sb, Map.Entry entry)
	{
		sb.append("<li><code><b>").append(entry.getKey()).
				append("</b> = ").append(entry.getValue()).append("</code></li>");
	}
}
